package com.TheLuckyPerson.loopMod.setup;

import net.minecraft.world.World;

public interface IProxy {

    World getClientWorld();
}
