package com.TheLuckyPerson.loopMod.setup.blocks;

import net.minecraftforge.registries.ObjectHolder;

public class ModBlocks {

    @ObjectHolder("loopmod:testblock")
    public static TestBlock TESTBLOCK;
}
